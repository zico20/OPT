import { getConfig } from "./config.js";
import { shouldSendAlert, buildTelegramMessage } from "./alertRules.js";
import { sendTelegramMessage } from "./telegram.js";
import { runOperationalInference, exportOperationalAssets } from "./earthEngine.js";
import { readCollection, writeCollection, replaceLatestRun } from "./dataStore.js";

function parseBooleanFlag(value) {
  if (value === undefined || value === null || value === "") {
    return undefined;
  }

  const normalized = String(value).trim().toLowerCase();
  if (["1", "true", "yes", "y", "on"].includes(normalized)) {
    return true;
  }
  if (["0", "false", "no", "n", "off"].includes(normalized)) {
    return false;
  }
  return undefined;
}

function parseArgs(argv) {
  const args = {};
  for (const item of argv.slice(2)) {
    if (item.startsWith("--date=")) {
      args.date = item.slice("--date=".length);
      continue;
    }

    if (item === "--export-first") {
      args.exportFirst = true;
      continue;
    }

    if (item.startsWith("--export-first=")) {
      args.exportFirst = parseBooleanFlag(item.slice("--export-first=".length));
    }
  }
  return args;
}

function getTodayString() {
  return new Date().toISOString().slice(0, 10);
}

async function buildAlertEvents({ run, districtRiskDaily, config }) {
  const rules = await readCollection("alertRules");
  const subscribers = await readCollection("subscribers");
  const activeSubscribers = subscribers.filter((subscriber) => subscriber.enabled);
  const alertEvents = [];

  for (const district of districtRiskDaily) {
    const alert = shouldSendAlert(district, rules);
    if (!alert) {
      continue;
    }

    const message = buildTelegramMessage({
      runDate: run.run_date,
      district,
      appUrl: config.publicAppUrl,
      severity: alert.severity,
      triggerReason: alert.trigger_reason
    });

    let scopedSubscribers = activeSubscribers.filter((subscriber) => (
      subscriber.district_scope === "all" || subscriber.district_scope === district.district_id
    ));

    if (scopedSubscribers.length === 0 && config.telegramDefaultChatId) {
      scopedSubscribers = [{
        subscriber_id: "env_default",
        district_scope: "all",
        chat_id: config.telegramDefaultChatId,
        enabled: true
      }];
    }

    let messageStatus = "skipped";
    if (scopedSubscribers.length > 0) {
      const results = await Promise.all(scopedSubscribers.map((subscriber) => (
        sendTelegramMessage({
          botToken: config.telegramBotToken,
          chatId: subscriber.chat_id || config.telegramDefaultChatId,
          message
        })
      )));
      messageStatus = results.every((result) => result.ok) ? "sent" : "partial";
      if (results.every((result) => result.skipped)) {
        messageStatus = "preview";
      }
    }

    alertEvents.push({
      alert_id: `alert_${run.run_date.replaceAll("-", "")}_${district.district_id}`,
      run_id: run.run_id,
      district_id: district.district_id,
      district_name: district.district_name,
      severity: alert.severity,
      trigger_reason: alert.trigger_reason,
      max_fire_prob: district.max_fire_prob,
      high_or_very_high_area_pct: district.high_or_very_high_area_pct,
      hotspot_count_24h: district.hotspot_count_24h,
      channel: "telegram",
      message_status: messageStatus,
      sent_at: new Date().toISOString(),
      preview_message: message
    });
  }

  return alertEvents;
}

export async function runDaily({ date, exportFirst } = {}) {
  const config = getConfig();
  const runDate = date || getTodayString();
  const shouldExportFirst = typeof exportFirst === "boolean"
    ? exportFirst
    : config.workerExportBeforeRun;

  let exportSummary = null;
  if (shouldExportFirst) {
    if (config.useMockEarthEngine) {
      throw new Error(
        "Cannot export operational assets while WORKER_USE_MOCK_EE=true. " +
        "Set WORKER_USE_MOCK_EE=false or call run-daily without export-first."
      );
    }
    exportSummary = await exportOperationalAssets({ runDate });
  }

  const inference = await runOperationalInference({
    runDate,
    useMockEarthEngine: config.useMockEarthEngine
  });

  const alertEvents = await buildAlertEvents({
    run: inference.run,
    districtRiskDaily: inference.districtRiskDaily,
    config
  });

  await replaceLatestRun(inference.run);
  await writeCollection("districtRiskDaily", inference.districtRiskDaily);
  await writeCollection("activeFireDaily", inference.activeFireDaily);
  await writeCollection("alertEvents", alertEvents);

  return {
    run: inference.run,
    districtCount: inference.districtRiskDaily.length,
    activeFireCount: inference.activeFireDaily.length,
    alertCount: alertEvents.length,
    exportFirst: shouldExportFirst,
    exportSummary
  };
}

const args = parseArgs(process.argv);

if (process.argv[1] && process.argv[1].endsWith("runDaily.js")) {
  runDaily({
    date: args.date,
    exportFirst: args.exportFirst
  })
    .then((result) => {
      process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    })
    .catch((error) => {
      process.stderr.write(`${error.stack}\n`);
      process.exitCode = 1;
    });
}

