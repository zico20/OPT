import "leaflet/dist/leaflet.css";
import "./globals.css";
import { IBM_Plex_Sans, Noto_Sans_Arabic, Sora } from "next/font/google";

const displayFont = Sora({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["400", "500", "600", "700", "800"]
});

const bodyFont = IBM_Plex_Sans({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600", "700"]
});

const rtlFont = Noto_Sans_Arabic({
  subsets: ["arabic"],
  variable: "--font-body-rtl",
  weight: ["400", "500", "600", "700"]
});

export const metadata = {
  title: "HazardSignal",
  description: "Operational hazard monitoring dashboard, district summaries, and alert administration."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${displayFont.variable} ${bodyFont.variable} ${rtlFont.variable}`}
        suppressHydrationWarning
      >
        {children}
      </body>
    </html>
  );
}
