﻿import Link from "next/link";
import LocaleSwitch from "../../components/LocaleSwitch";
import MicroIcon from "../../components/MicroIcon";
import StickyMissionStrip from "../../components/StickyMissionStrip";
import MissionStatus from "../../components/MissionStatus";
import RiskMapShell from "../../components/RiskMapShell";
import TelegramSubscribePanel from "../../components/TelegramSubscribePanel";
import {
  getActiveFireDaily,
  getAlertEvents,
  getDistrictRiskDaily,
  getLatestRun,
  sortDistrictsByRisk
} from "../../lib/data";
import { formatPercent, formatProb, riskBadgeTone } from "../../lib/format";
import { getMessages, localizeRiskClass, localizeSeverity, normalizeLocale } from "../../lib/i18n";
import { deriveMissionState } from "../../lib/mission";

export default async function DashboardPage({ params }) {
  const resolvedParams = await params;
  const locale = normalizeLocale(resolvedParams.lang);
  const messages = getMessages(locale);

  const [latestRun, districtRows, fires, alerts] = await Promise.all([
    getLatestRun(),
    getDistrictRiskDaily(),
    getActiveFireDaily(),
    getAlertEvents()
  ]);

  const districts = sortDistrictsByRisk(districtRows);
  const topDistricts = districts.slice(0, 8);
  const recentAlerts = alerts.slice(0, 8);
  const missionState = deriveMissionState({ latestRun, districts, fires, alerts: recentAlerts });

  const runDate = latestRun?.run_date || "-";
  const selectedThreshold = latestRun ? formatProb(latestRun.selected_threshold, locale) : "-";
  const criticalDistricts = latestRun?.critical_districts ?? 0;
  const activeFireDistricts = latestRun?.active_fire_districts ?? 0;
  const highestArea = districts[0]?.high_or_very_high_area_pct ?? 0;
  const focusLabel = fires[0]?.district_name || topDistricts[0]?.district_name || "";

  const shellClass = [
    "shell",
    "home-shell",
    "mission-shell",
    "mission-" + missionState,
    messages.dir === "rtl" ? "rtl" : ""
  ].filter(Boolean).join(" ");

  const snapshotCards = [
    { label: messages.home.criticalDistricts, value: criticalDistricts },
    { label: messages.alerts.status, value: latestRun?.status || "-" },
    { label: messages.home.highArea, value: formatPercent(highestArea, locale) },
    { label: messages.home.hotspots, value: activeFireDistricts }
  ];

  return (
    <div className={shellClass} dir={messages.dir}>
      <header className="masthead mission-header">
        <div className="hero-grid">
          <div className="hero-copy">
            <span className="eyebrow hero-eyebrow">{messages.home.eyebrow}</span>
            <h1>{messages.appName}</h1>
            <p>{messages.home.intro}</p>

            <div className="hero-signal-row">
              <span className="signal-pill"><MicroIcon name="calendar" /><span>{messages.home.lastRun}: {runDate}</span></span>
              <span className="signal-pill"><MicroIcon name="flame" /><span>{messages.home.hotspots}: {activeFireDistricts}</span></span>
              <span className="signal-pill"><MicroIcon name="alert" /><span>{messages.home.criticalDistricts}: {criticalDistricts}</span></span>
            </div>

            <MissionStatus messages={messages} state={missionState} focusLabel={focusLabel} />

            <div className="topnav public-topnav">
              <Link href={"/" + locale}>{messages.nav.dashboard}</Link>
              <Link className="secondary" href={"/" + locale + "/alerts"}>
                {messages.nav.alerts}
              </Link>
              <Link className="secondary" href={"/" + locale + "/methodology"}>
                {messages.nav.methodology}
              </Link>
            </div>
          </div>

          <TelegramSubscribePanel
            messages={messages}
            title={messages.home.subscriptionTitle}
            body={messages.home.subscriptionBody}
            buttonOnly
          />
        </div>

        <LocaleSwitch locale={locale} path="/" locales={messages.locales} className="public-locale-switch" />

        <section className="hero-stats compact-stats">
          <article className="stat-card stat-card-compact">
            <div className="stat-label">{messages.home.lastRun}</div>
            <div className="stat-value stat-value-compact">{runDate}</div>
          </article>
          <article className="stat-card stat-card-compact">
            <div className="stat-label">{messages.home.threshold}</div>
            <div className="stat-value stat-value-compact">{selectedThreshold}</div>
          </article>
          <article className="stat-card stat-card-compact">
            <div className="stat-label">{messages.home.criticalDistricts}</div>
            <div className="stat-value stat-value-compact">{criticalDistricts}</div>
          </article>
          <article className="stat-card stat-card-compact">
            <div className="stat-label">{messages.home.activeFireDistricts}</div>
            <div className="stat-value stat-value-compact">{activeFireDistricts}</div>
          </article>
        </section>
      </header>

      <StickyMissionStrip messages={messages} state={missionState} focusLabel={focusLabel} />

      <section className="section-grid">
        <article className="panel" style={{ gridColumn: "span 8" }}>
          <h2>{messages.home.mapTitle}</h2>
          <p>{messages.home.mapDesc}</p>
          <RiskMapShell districts={districts} fires={fires} messages={messages.map} locale={locale} missionState={missionState} />
        </article>

        <aside className="panel snapshot-panel" style={{ gridColumn: "span 4" }}>
          <h3>{messages.home.snapshot}</h3>
          <div className="snapshot-grid">
            {snapshotCards.map((entry) => (
              <article className="snapshot-tile" key={entry.label}>
                <span className="snapshot-label">{entry.label}</span>
                <strong className="snapshot-value">{entry.value}</strong>
              </article>
            ))}
          </div>

          <div className="snapshot-note">
            <span className="eyebrow">{messages.common.note}</span>
            <p>{messages.common.decisionSupport}</p>
            <Link className="button secondary" href={"/" + locale + "/methodology"}>
              {messages.nav.methodology}
            </Link>
          </div>
        </aside>
      </section>

      <section className="split split-feed" style={{ marginTop: 18 }}>
        <article className="panel district-table ops-table-panel">
          <h3>{messages.home.leaderboard}</h3>
          <div className="ops-table-wrap">
            <table className="ops-table ops-mobile-feed">
              <thead>
                <tr>
                  <th>#</th>
                  <th>{messages.home.district}</th>
                  <th>{messages.home.classLabel}</th>
                  <th>{messages.home.maxProb}</th>
                  <th>{messages.home.highArea}</th>
                  <th>{messages.home.hotspots}</th>
                </tr>
              </thead>
              <tbody>
                {topDistricts.map((district, index) => (
                  <tr key={district.district_id}>
                    <td data-label="#">
                      <span className="ops-index">{String(index + 1).padStart(2, "0")}</span>
                    </td>
                    <td data-label={messages.home.district}>
                      <div className="ops-row-title">
                        <Link href={"/" + locale + "/districts/" + district.district_id}>{district.district_name}</Link>
                      </div>
                                          </td>
                    <td data-label={messages.home.classLabel}>
                      <span className={["badge", riskBadgeTone(district.dominant_risk_class)].join(" ")}>
                        {localizeRiskClass(district.dominant_risk_class, locale)}
                      </span>
                    </td>
                    <td className="ops-number" data-label={messages.home.maxProb}>{formatProb(district.max_fire_prob, locale)}</td>
                    <td className="ops-number" data-label={messages.home.highArea}>{formatPercent(district.high_or_very_high_area_pct, locale)}</td>
                    <td className="ops-number" data-label={messages.home.hotspots}>{district.hotspot_count_24h}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </article>

        <article className="panel alert-list ops-feed-panel feed-panel-mobile">
          <h3>{messages.home.feed}</h3>
          {recentAlerts.length === 0 ? (
            <p className="muted">-</p>
          ) : (
            recentAlerts.map((alert) => (
              <div className="ops-event-card" key={alert.alert_id}>
                <div className="ops-event-head">
                  <div>
                    <div className="ops-row-title">{alert.district_name}</div>
                    <div className="ops-row-sub">{alert.trigger_reason}</div>
                  </div>
                  <div className={["badge", riskBadgeTone(alert.severity)].join(" ")}>
                    {localizeSeverity(alert.severity, locale)}
                  </div>
                </div>
                <div className="ops-metric-strip">
                  <span className="pill">{messages.home.probability}: {formatProb(alert.max_fire_prob, locale)}</span>
                  <span className="pill">{messages.home.area}: {formatPercent(alert.high_or_very_high_area_pct, locale)}</span>
                  <span className="pill">{messages.home.hotspots}: {alert.hotspot_count_24h}</span>
                </div>
              </div>
            ))
          )}
        </article>
      </section>

      <section className="panel footnote-panel" style={{ marginTop: 18 }}>
        <h3>{messages.common.note}</h3>
        <p className="muted">{messages.alerts.noteBody}</p>
        <p className="footnote">{messages.common.decisionSupport}</p>
      </section>
    </div>
  );
}



